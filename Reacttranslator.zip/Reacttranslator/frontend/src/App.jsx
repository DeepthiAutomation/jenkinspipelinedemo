import { useEffect, useMemo, useRef, useState } from 'react';

const LANGUAGES = { English: 'en', Hindi: 'hi', Marathi: 'mr', Telugu: 'te' };
const LANGUAGE_OPTIONS = Object.keys(LANGUAGES);

function App() {
  const [activeTab, setActiveTab] = useState('text');
  const [statusMessage, setStatusMessage] = useState('Offline AI translation for text, images, PDFs, videos and live voice.');

  const [textInput, setTextInput] = useState('');
  const [textSource, setTextSource] = useState('English');
  const [textTarget, setTextTarget] = useState('Hindi');
  const [textTranslation, setTextTranslation] = useState('');
  const [textLoading, setTextLoading] = useState(false);

  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState('');
  const [imageSource, setImageSource] = useState('English');
  const [imageTarget, setImageTarget] = useState('Hindi');
  const [imageText, setImageText] = useState('');
  const [imageTranslation, setImageTranslation] = useState('');
  const [imageLoading, setImageLoading] = useState(false);

  const [pdfFile, setPdfFile] = useState(null);
  const [pdfSource, setPdfSource] = useState('English');
  const [pdfTarget, setPdfTarget] = useState('Hindi');
  const [pdfText, setPdfText] = useState('');
  const [pdfTranslation, setPdfTranslation] = useState('');
  const [pdfLoading, setPdfLoading] = useState(false);

  const [videoFile, setVideoFile] = useState(null);
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [videoSource, setVideoSource] = useState('English');
  const [videoTarget, setVideoTarget] = useState('Hindi');
  const [burnSubtitles, setBurnSubtitles] = useState(false);
  const [videoTranscript, setVideoTranscript] = useState('');
  const [videoTranslation, setVideoTranslation] = useState('');
  const [videoSubtitles, setVideoSubtitles] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [videoLoading, setVideoLoading] = useState(false);
  const [videoAudioUrl, setVideoAudioUrl] = useState('');

  const [liveAudioBlob, setLiveAudioBlob] = useState(null);
  const [liveAudioUrl, setLiveAudioUrl] = useState('');
  const [liveTranscript, setLiveTranscript] = useState('');
  const [liveTranslation, setLiveTranslation] = useState('');
  const [liveLoading, setLiveLoading] = useState(false);
  const [recording, setRecording] = useState(false);
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);

  useEffect(() => {
    return () => {
      if (imagePreview) URL.revokeObjectURL(imagePreview);
      if (liveAudioUrl) URL.revokeObjectURL(liveAudioUrl);
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    };
  }, [imagePreview, liveAudioUrl, videoUrl]);

  const isBusy = useMemo(() => textLoading || imageLoading || pdfLoading || videoLoading || liveLoading, [textLoading, imageLoading, pdfLoading, videoLoading, liveLoading]);

  const handleTextTranslate = async () => {
    if (!textInput.trim()) return;
    setTextLoading(true);
    setStatusMessage('Preparing offline translation model...');
    try {
      const response = await fetch('/api/text/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: textInput,
          source_language: textSource,
          target_language: textTarget,
        }),
      });
      const data = await response.json();
      if (data.status === 'failed') {
        setStatusMessage(`Text translation failed: ${data.error || 'unknown error'}`);
        setTextTranslation('');
      } else {
        setTextTranslation(data.translation || '');
        setStatusMessage('Translation complete.');
      }
    } catch (error) {
      setStatusMessage('Text translation failed.');
      setTextTranslation('');
    } finally {
      setTextLoading(false);
    }
  };

  const handleImageExtract = async () => {
    if (!imageFile) return;
    setImageLoading(true);
    setStatusMessage('Reading image with OCR...');
    try {
      const formData = new FormData();
      formData.append('file', imageFile);
      formData.append('source_language', imageSource);
      const response = await fetch('/api/image/extract', { method: 'POST', body: formData });
      const data = await response.json();
      if (data.status === 'failed') {
        setStatusMessage(`Image OCR failed: ${data.error || 'unknown error'}`);
      } else {
        setStatusMessage('Image OCR complete.');
      }
      setImageText(data.extracted_text || '');
      setImageTranslation('');
    } catch (error) {
      setStatusMessage('Image OCR failed.');
    } finally {
      setImageLoading(false);
    }
  };

  const handleImageTranslate = async () => {
    if (!imageText.trim()) return;
    setImageLoading(true);
    setStatusMessage('Translating extracted image text...');
    try {
      const response = await fetch('/api/image/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: imageText,
          source_language: imageSource,
          target_language: imageTarget,
        }),
      });
      const data = await response.json();
      if (data.status === 'failed') {
        setStatusMessage(`Image translation failed: ${data.error || 'unknown error'}`);
      } else {
        setStatusMessage('Image translation complete.');
      }
      setImageTranslation(data.translation || '');
    } catch (error) {
      setStatusMessage('Image translation failed.');
    } finally {
      setImageLoading(false);
    }
  };

  const handlePdfExtract = async () => {
    if (!pdfFile) return;
    setPdfLoading(true);
    setStatusMessage('Extracting text from PDF...');
    try {
      const formData = new FormData();
      formData.append('file', pdfFile);
      formData.append('source_language', pdfSource);
      const response = await fetch('/api/pdf/extract', { method: 'POST', body: formData });
      const data = await response.json();
      setPdfText(data.extracted_text || '');
      setPdfTranslation('');
    } catch (error) {
      setStatusMessage('PDF extraction failed.');
    } finally {
      setPdfLoading(false);
    }
  };

  const handlePdfTranslate = async () => {
    if (!pdfText.trim()) return;
    setPdfLoading(true);
    setStatusMessage('Translating PDF text...');
    try {
      const response = await fetch('/api/pdf/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: pdfText,
          source_language: pdfSource,
          target_language: pdfTarget,
        }),
      });
      const data = await response.json();
      setPdfTranslation(data.translation || '');
    } catch (error) {
      setStatusMessage('PDF translation failed.');
    } finally {
      setPdfLoading(false);
    }
  };

  const handleVideoProcess = async () => {
    setVideoLoading(true);
    setStatusMessage('Step 1/5: Transcribing speech from video...');
    try {
      const formData = new FormData();
      if (videoFile) formData.append('file', videoFile);
      if (youtubeUrl) formData.append('youtube_url', youtubeUrl);
      formData.append('source_language', videoSource);
      formData.append('target_language', videoTarget);
      const response = await fetch('/api/video/process', { method: 'POST', body: formData });
      const data = await response.json();
      setVideoTranscript(data.transcript || '');
      setVideoTranslation(data.translation || '');
      setVideoSubtitles(data.subtitles || '');
      if (data.error) {
        setStatusMessage(`Video processing warning: ${data.error}`);
      } else {
        setStatusMessage('Video speech and translation are ready.');
      }
    } catch (error) {
      setStatusMessage('Video processing failed.');
    } finally {
      setVideoLoading(false);
    }
  };

  const handleVideoDub = async () => {
    if (!videoFile && !youtubeUrl) return;
    setVideoLoading(true);
    setStatusMessage('Building dubbed video...');
    try {
      const formData = new FormData();
      if (videoFile) formData.append('file', videoFile);
      if (youtubeUrl) formData.append('youtube_url', youtubeUrl);
      formData.append('source_language', videoSource);
      formData.append('target_language', videoTarget);
      formData.append('burn_subtitles', burnSubtitles ? 'true' : 'false');
      const response = await fetch('/api/video/dub', { method: 'POST', body: formData });
      const blob = await response.blob();
      if (videoUrl) URL.revokeObjectURL(videoUrl);
      const url = URL.createObjectURL(blob);
      setVideoUrl(url);
      if (videoAudioUrl) URL.revokeObjectURL(videoAudioUrl);
      setVideoAudioUrl('');
    } catch (error) {
      setStatusMessage('Video dubbing failed.');
    } finally {
      setVideoLoading(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : 'audio/webm';
      const recorder = new MediaRecorder(stream, { mimeType });
      chunksRef.current = [];
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) chunksRef.current.push(event.data);
      };
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mimeType });
        setLiveAudioBlob(blob);
        const url = URL.createObjectURL(blob);
        setLiveAudioUrl((previous) => {
          if (previous) URL.revokeObjectURL(previous);
          return url;
        });
        stream.getTracks().forEach((track) => track.stop());
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setRecording(true);
      setStatusMessage('Recording audio... speak clearly.');
    } catch (error) {
      setStatusMessage('Microphone access was blocked.');
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setRecording(false);
  };

  const handleLiveTranslate = async () => {
    if (!liveAudioBlob) return;
    setLiveLoading(true);
    setStatusMessage('Step 1/3: Transcribing speech...');
    try {
      const formData = new FormData();
      const audioFileName = liveAudioBlob.type.includes('wav') ? 'recording.wav' : 'recording.webm';
      formData.append('file', liveAudioBlob, audioFileName);
      formData.append('source_language', 'Hindi');
      formData.append('target_language', 'English');
      const response = await fetch('/api/live/translate', { method: 'POST', body: formData });
      const data = await response.json();
      setLiveTranscript(data.transcript || '');
      setLiveTranslation(data.translation || '');
      if (data.error) {
        setStatusMessage(`Live translation notice: ${data.error}`);
      } else {
        setStatusMessage('Live translation ready.');
      }
      if (data.audio) {
        const bytes = Uint8Array.from(atob(data.audio), (c) => c.charCodeAt(0));
        const audioBlob = new Blob([bytes], { type: 'audio/wav' });
        const url = URL.createObjectURL(audioBlob);
        setLiveAudioUrl((previous) => {
          if (previous) URL.revokeObjectURL(previous);
          return url;
        });
      }
    } catch (error) {
      setStatusMessage('Live translation failed.');
    } finally {
      setLiveLoading(false);
    }
  };

  const preloadModel = async (endpoint) => {
    setStatusMessage('Loading offline model...');
    try {
      await fetch(endpoint, { method: 'POST' });
      setStatusMessage('Model ready.');
    } catch (error) {
      setStatusMessage('Model preload failed.');
    }
  };

  const tabs = [
    { id: 'text', label: 'Text' },
    { id: 'image', label: 'Image OCR' },
    { id: 'pdf', label: 'PDF OCR' },
    { id: 'video', label: 'Video Dubbing' },
    { id: 'live', label: 'Live Translation' },
  ];

  return (
    <div className="app-shell">
      <div className="hero-card">
        <h1>GramSetu AI Offline</h1>
        <p>Offline translation for field trainers, farmers, images, PDFs, videos and live voice conversations.</p>
      </div>

      <div className="notice-card">Offline models are loaded on first use and run locally for text, OCR, speech and video dubbing.</div>

      <div className="steps-grid">
        {['Speak or upload', 'Extract text/speech', 'Translate offline', 'Listen or download'].map((step, index) => (
          <div className="step-card" key={step}>
            <b>{index + 1}</b>
            <span>{step}</span>
          </div>
        ))}
      </div>

      <div className="layout-grid">
        <aside className="sidebar-card">
          <h3>Offline Models</h3>
          <button onClick={() => preloadModel('/api/preload/translation')}>Preload Translation</button>
          <button onClick={() => preloadModel('/api/preload/whisper')}>Preload Speech</button>
          <button onClick={() => preloadModel('/api/preload/tts')}>Preload TTS</button>
          <button onClick={() => preloadModel('/api/preload/ocr')}>Preload OCR</button>
          <div className="status-box">{statusMessage}</div>
        </aside>

        <section className="main-card">
          <div className="tab-row">
            {tabs.map((tab) => (
              <button key={tab.id} className={activeTab === tab.id ? 'tab active' : 'tab'} onClick={() => setActiveTab(tab.id)}>
                {tab.label}
              </button>
            ))}
          </div>

          {activeTab === 'text' && (
            <div className="tab-content">
              <h2>Translate Text</h2>
              <textarea value={textInput} onChange={(e) => setTextInput(e.target.value)} rows={8} placeholder="Type or paste text here..." />
              <div className="field-grid">
                <label>
                  From
                  <select value={textSource} onChange={(e) => setTextSource(e.target.value)}>
                    {LANGUAGE_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
                <label>
                  To
                  <select value={textTarget} onChange={(e) => setTextTarget(e.target.value)}>
                    {LANGUAGE_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
              </div>
              <div className="button-row">
                <button className="primary" onClick={handleTextTranslate} disabled={textLoading || !textInput.trim()}>{textLoading ? 'Translating...' : 'Translate Text'}</button>
              </div>
              {textTranslation && <div className="result-box"><h3>Translation</h3><p>{textTranslation}</p></div>}
            </div>
          )}

          {activeTab === 'image' && (
            <div className="tab-content">
              <h2>Image OCR Translation</h2>
              <input type="file" accept="image/*" onChange={(event) => { const file = event.target.files?.[0]; if (file) { setImageFile(file); setImagePreview(URL.createObjectURL(file)); setImageText(''); setImageTranslation(''); } }} />
              {imagePreview && <img src={imagePreview} alt="Uploaded preview" className="preview-image" />}
              <div className="field-grid">
                <label>
                  Image language
                  <select value={imageSource} onChange={(e) => setImageSource(e.target.value)}>
                    {LANGUAGE_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
                <label>
                  Translate to
                  <select value={imageTarget} onChange={(e) => setImageTarget(e.target.value)}>
                    {LANGUAGE_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
              </div>
              <div className="button-row">
                <button className="primary" onClick={handleImageExtract} disabled={imageLoading || !imageFile}>{imageLoading ? 'Reading...' : 'Extract Text from Image'}</button>
              </div>
              {imageText && (
                <>
                  <textarea value={imageText} onChange={(e) => setImageText(e.target.value)} rows={6} />
                  <div className="button-row">
                    <button className="primary" onClick={handleImageTranslate} disabled={imageLoading || !imageText.trim()}>{imageLoading ? 'Translating...' : 'Translate Image Text'}</button>
                  </div>
                </>
              )}
              {imageTranslation && <div className="result-box"><h3>Translation</h3><p>{imageTranslation}</p></div>}
            </div>
          )}

          {activeTab === 'pdf' && (
            <div className="tab-content">
              <h2>PDF OCR Translation</h2>
              <input type="file" accept="application/pdf" onChange={(event) => { const file = event.target.files?.[0]; setPdfFile(file || null); setPdfText(''); setPdfTranslation(''); }} />
              <div className="field-grid">
                <label>
                  PDF language
                  <select value={pdfSource} onChange={(e) => setPdfSource(e.target.value)}>
                    {LANGUAGE_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
                <label>
                  Translate to
                  <select value={pdfTarget} onChange={(e) => setPdfTarget(e.target.value)}>
                    {LANGUAGE_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
              </div>
              <div className="button-row">
                <button className="primary" onClick={handlePdfExtract} disabled={pdfLoading || !pdfFile}>{pdfLoading ? 'Extracting...' : 'Extract Text from PDF'}</button>
              </div>
              {pdfText && (
                <>
                  <textarea value={pdfText} onChange={(e) => setPdfText(e.target.value)} rows={10} />
                  <div className="button-row">
                    <button className="primary" onClick={handlePdfTranslate} disabled={pdfLoading || !pdfText.trim()}>{pdfLoading ? 'Translating...' : 'Translate PDF Text'}</button>
                  </div>
                </>
              )}
              {pdfTranslation && <div className="result-box"><h3>Translation</h3><p>{pdfTranslation}</p></div>}
            </div>
          )}

          {activeTab === 'video' && (
            <div className="tab-content">
              <h2>Video Speech Translation & Dubbing</h2>
              <input type="file" accept="video/*" onChange={(event) => { const file = event.target.files?.[0]; setVideoFile(file || null); }} />
              <input value={youtubeUrl} onChange={(e) => setYoutubeUrl(e.target.value)} placeholder="Optional YouTube link" />
              <div className="field-grid">
                <label>
                  Spoken language
                  <select value={videoSource} onChange={(e) => setVideoSource(e.target.value)}>
                    {LANGUAGE_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
                <label>
                  Dub voice to
                  <select value={videoTarget} onChange={(e) => setVideoTarget(e.target.value)}>
                    {LANGUAGE_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
              </div>
              <label className="checkbox-row">
                <input type="checkbox" checked={burnSubtitles} onChange={(e) => setBurnSubtitles(e.target.checked)} />
                Burn translated subtitles into video
              </label>
              <div className="button-row">
                <button className="primary" onClick={handleVideoProcess} disabled={videoLoading || (!videoFile && !youtubeUrl.trim())}>{videoLoading ? 'Processing...' : 'Process Video'}</button>
                <button onClick={handleVideoDub} disabled={videoLoading || (!videoFile && !youtubeUrl.trim())}>Build Dubbed Video</button>
              </div>
              {videoTranscript && <div className="result-box"><h3>Transcript</h3><p>{videoTranscript}</p></div>}
              {videoTranslation && <div className="result-box"><h3>Translation</h3><p>{videoTranslation}</p></div>}
              {videoSubtitles && <div className="result-box"><h3>Subtitles</h3><pre>{videoSubtitles}</pre></div>}
              {videoUrl && <div className="result-box"><h3>Dubbed Video</h3><video controls src={videoUrl} className="video-preview" /></div>}
            </div>
          )}

          {activeTab === 'live' && (
            <div className="tab-content">
              <h2>Live Voice Translation</h2>
              <p>Record a short voice clip and the app will transcribe and translate it offline.</p>
              <div className="button-row">
                {!recording ? <button className="primary" onClick={startRecording}>Start Recording</button> : <button onClick={stopRecording}>Stop Recording</button>}
                <button onClick={handleLiveTranslate} disabled={liveLoading || !liveAudioBlob}>Translate Recorded Voice</button>
              </div>
              {liveAudioUrl && <audio controls src={liveAudioUrl} className="audio-preview" />}
              {liveTranscript && <div className="result-box"><h3>Transcript</h3><p>{liveTranscript}</p></div>}
              {liveTranslation && <div className="result-box"><h3>Translation</h3><p>{liveTranslation}</p></div>}
              {liveAudioUrl && <div className="result-box"><h3>Translated Voice</h3><audio controls src={liveAudioUrl} className="audio-preview" /></div>}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

export default App;

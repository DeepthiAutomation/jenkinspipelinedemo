import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.append(str(Path(__file__).resolve().parents[1]))

import main


class VideoProcessingTests(unittest.TestCase):
    def test_transcribe_video_reports_audio_extraction_error(self):
        class FakeModel:
            def transcribe(self, path, **kwargs):
                raise ValueError("bad input")

        class FakeCompletedProcess:
            returncode = 1
            stderr = "ffmpeg failed"

        with mock.patch.object(main, "load_whisper_model", return_value=FakeModel()), mock.patch.object(main.subprocess, "run", return_value=FakeCompletedProcess()):
            transcript, blocks, error = main.transcribe_video("video.mp4", "en")

        self.assertEqual(transcript, "")
        self.assertEqual(blocks, [])
        self.assertIn("could not be extracted", error)


if __name__ == "__main__":
    unittest.main()

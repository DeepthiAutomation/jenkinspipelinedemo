import sys
import unittest
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))

from main import get_translation_model_name


class TranslationModelSelectionTests(unittest.TestCase):
    def test_returns_small_model_for_english_to_hindi(self):
        self.assertEqual(get_translation_model_name("en", "hi"), "Helsinki-NLP/opus-mt-en-hi")

    def test_returns_nllb_fallback_for_unsupported_pair(self):
        self.assertEqual(get_translation_model_name("en", "fr"), "facebook/nllb-200-distilled-600M")


if __name__ == "__main__":
    unittest.main()


import base64
import io
import os
import re
import shutil
import subprocess
import tempfile
import warnings
from concurrent.futures import ThreadPoolExecutor, TimeoutError
from functools import lru_cache
from typing import Optional

import numpy as np
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from PIL import Image, ImageEnhance

warnings.filterwarnings("ignore")

app = FastAPI(title="GramSetu AI Offline API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

FFMPEG_EXE = r"C:\Users\Skandan Anumala\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-8.1.2-full_build\bin\ffmpeg.exe"
FFPROBE_EXE = FFMPEG_EXE.replace("ffmpeg.exe", "ffprobe.exe")
if not os.path.exists(FFMPEG_EXE):
    FFMPEG_EXE = shutil.which("ffmpeg") or "ffmpeg"
    FFPROBE_EXE = shutil.which("ffprobe") or "ffprobe"

LANGUAGES = {"English": "en", "Hindi": "hi", "Marathi": "mr", "Telugu": "te"}
NLLB_CODES = {"en": "eng_Latn", "hi": "hin_Deva", "mr": "mar_Deva", "te": "tel_Telu"}
MARIAN_CODES = {"en": "eng", "hi": "hin", "mr": "mar", "te": "tel"}
WHISPER_CODES = {"en": "en", "hi": "hi", "mr": "mr", "te": "te"}
MMS_TTS_MODELS = {"en": "facebook/mms-tts-eng", "hi": "facebook/mms-tts-hin", "mr": "facebook/mms-tts-mar", "te": "facebook/mms-tts-tel"}
TRANSLATION_EXECUTOR = ThreadPoolExecutor(max_workers=1)


def clean_text_for_tts(text: str) -> str:
    return re.sub(r"\s+", " ", str(text).strip()).replace("।", ".")


def get_translation_model_name(src: str, tgt: str) -> str:
    if src == "en" and tgt == "hi":
        return "Helsinki-NLP/opus-mt-en-hi"
    if src == "hi" and tgt == "en":
        return "Helsinki-NLP/opus-mt-hi-en"
    return "facebook/nllb-200-distilled-600M"


@lru_cache(maxsize=2)
def load_translation_model(src: str, tgt: str):
    from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

    name = get_translation_model_name(src, tgt)
    tokenizer = AutoTokenizer.from_pretrained(name)
    model = AutoModelForSeq2SeqLM.from_pretrained(name)
    return tokenizer, model


def translate_chunk(text: str, src: str, tgt: str) -> str:
    if src == tgt:
        return text
    try:
        tokenizer, model = load_translation_model(src, tgt)
        if get_translation_model_name(src, tgt) == "facebook/nllb-200-distilled-600M":
            tokenizer.src_lang = NLLB_CODES.get(src, src)
            target = NLLB_CODES.get(tgt, tgt)
            inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=512)
            bos = tokenizer.lang_code_to_id[target] if hasattr(tokenizer, "lang_code_to_id") else tokenizer.convert_tokens_to_ids(target)
            output = model.generate(**inputs, forced_bos_token_id=bos, max_length=512)
            return tokenizer.batch_decode(output, skip_special_tokens=True)[0]
        tokenizer.src_lang = MARIAN_CODES.get(src, src)
        tokenizer.tgt_lang = MARIAN_CODES.get(tgt, tgt)
        inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
        output = model.generate(**inputs, max_length=512)
        return tokenizer.batch_decode(output, skip_special_tokens=True)[0]
    except Exception:
        if src == "en" and tgt in {"hi", "mr", "te"}:
            return "Translation unavailable right now. Please try again shortly."
        return text


def translate_text(text: str, src: str, tgt: str) -> str:
    text = str(text).strip()
    if not text or src == tgt:
        return text
    if len(text) <= 700:
        return translate_chunk(text, src, tgt)
    chunks = []
    current = ""
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if len(current) + len(line) + 1 > 700:
            if current:
                chunks.append(current)
            current = line
        else:
            current = current + "\n" + line if current else line
    if current:
        chunks.append(current)
    return "\n".join(translate_chunk(chunk, src, tgt) for chunk in chunks)


@lru_cache(maxsize=4)
def load_tts_model(lang: str):
    from transformers import AutoTokenizer, VitsModel

    name = MMS_TTS_MODELS[lang]
    model = VitsModel.from_pretrained(name)
    tokenizer = AutoTokenizer.from_pretrained(name)
    return model, tokenizer


def create_audio(text: str, lang: str, max_chars: int = 900):
    import scipy.io.wavfile
    import torch

    text = clean_text_for_tts(text)
    if not text:
        return None
    if len(text) > max_chars:
        text = text[:max_chars]
    model, tokenizer = load_tts_model(lang)
    inputs = tokenizer(text, return_tensors="pt")
    if "input_ids" in inputs and inputs["input_ids"].shape[-1] < 2:
        text += "."
        inputs = tokenizer(text, return_tensors="pt")
    with torch.no_grad():
        waveform = model(**inputs).waveform.squeeze().numpy()
    buffer = io.BytesIO()
    scipy.io.wavfile.write(buffer, model.config.sampling_rate, waveform)
    buffer.seek(0)
    return buffer.read()


@lru_cache(maxsize=1)
def load_whisper_model():
    from faster_whisper import WhisperModel

    return WhisperModel("tiny", device="cpu", compute_type="int8")


def transcribe_audio_file(path: str, src: str, tgt: Optional[str] = None):
    model = load_whisper_model()
    task = "translate" if tgt == "en" and src != "en" else "transcribe"
    segments, _ = model.transcribe(path, language=WHISPER_CODES.get(src), task=task, beam_size=5, vad_filter=False, condition_on_previous_text=False)
    return " ".join(segment.text.strip() for segment in segments if segment.text.strip())


@lru_cache(maxsize=4)
def load_ocr_reader(lang: str):
    import easyocr

    language_map = {"en": ["en"], "hi": ["hi", "en"], "mr": ["mr", "en"], "te": ["te", "en"]}
    return easyocr.Reader(language_map.get(lang, ["en"]), gpu=False)


def preprocess_for_ocr(img: Image.Image) -> Image.Image:
    img = img.convert("RGB")
    width, height = img.size
    if max(width, height) < 1800:
        scale = 1800 / max(width, height)
        img = img.resize((int(width * scale), int(height * scale)), Image.LANCZOS)
    return ImageEnhance.Sharpness(ImageEnhance.Contrast(img).enhance(1.8)).enhance(1.7)


def ocr_image(img: Image.Image, lang: str) -> str:
    try:
        results = load_ocr_reader(lang).readtext(np.array(preprocess_for_ocr(img)), detail=0, paragraph=False)
        return "\n".join(str(item).strip() for item in results if str(item).strip())
    except Exception:
        return ""


def extract_pdf_text_and_images(pdf_bytes: bytes, lang: str) -> str:
    import fitz

    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    output = []
    for page_index, page in enumerate(doc):
        parts = []
        text_layer = page.get_text("text").strip()
        if text_layer:
            parts.append(text_layer)
        pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
        image = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        ocr_text = ocr_image(image, lang).strip()
        if ocr_text:
            parts.append(ocr_text)
        if parts:
            output.append("\n\n".join(parts))
    doc.close()
    return "\n\n".join(output)


def srt_time(sec: float) -> str:
    sec = max(0, float(sec))
    whole = int(sec)
    millis = int(round((sec - whole) * 1000))
    if millis >= 1000:
        whole += 1
        millis -= 1000
    return f"{whole // 3600:02}:{(whole % 3600) // 60:02}:{whole % 60:02},{millis:03}"


def get_video_duration(path: str) -> float:
    result = subprocess.run([FFPROBE_EXE, "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", path], capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(result.stderr)
    return float(result.stdout.strip())


def transcribe_video(path: str, src: str):
    model = load_whisper_model()
    try:
        segments, _ = model.transcribe(path, language=WHISPER_CODES.get(src), task="transcribe", beam_size=5, vad_filter=True, condition_on_previous_text=False)
    except Exception:
        audio_path = None
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as handle:
                audio_path = handle.name
            result = subprocess.run([FFMPEG_EXE, "-y", "-i", path, "-vn", "-ac", "1", "-ar", "16000", "-f", "wav", audio_path], capture_output=True, text=True)
            if result.returncode != 0:
                raise RuntimeError(result.stderr)
            segments, _ = model.transcribe(audio_path, language=WHISPER_CODES.get(src), task="transcribe", beam_size=5, vad_filter=True, condition_on_previous_text=False)
        except Exception as exc:
            return "", [], f"Audio could not be extracted from the video: {exc}"
        finally:
            if audio_path and os.path.exists(audio_path):
                os.remove(audio_path)
    parts = []
    blocks = []
    for index, segment in enumerate(segments, 1):
        text = segment.text.strip()
        if text:
            parts.append(text)
            blocks.append({"index": index, "start": float(segment.start), "end": float(segment.end), "text": text})
    return "\n".join(parts), blocks, None


def make_translated_srt(blocks, src: str, tgt: str) -> str:
    lines = []
    for index, block in enumerate(blocks, 1):
        lines.append(f"{index}\n{srt_time(block['start'])} --> {srt_time(block['end'])}\n{translate_text(block['text'], src, tgt).strip()}\n")
    return "\n".join(lines).strip() + "\n"


def create_segment_dubbed_audio(blocks, src: str, tgt: str):
    import scipy.io.wavfile
    import scipy.signal
    import torch

    if not blocks:
        return None
    sample_rate = 16000
    final_length = int(sample_rate * (int(blocks[-1]["end"] * 1000) + 2000) / 1000)
    final = np.zeros(final_length, dtype=np.float32)
    for index, block in enumerate(blocks, 1):
        start = int(block["start"] * 1000)
        end = int(block["end"] * 1000)
        slot = max(500, end - start)
        text = clean_text_for_tts(translate_text(block["text"], src, tgt))
        if not text:
            continue
        try:
            audio_bytes = create_audio(text, tgt, max_chars=220)
        except Exception:
            continue
        if not audio_bytes:
            continue
        sample_rate_in, data = scipy.io.wavfile.read(io.BytesIO(audio_bytes))
        if data.ndim > 1:
            data = data.mean(axis=1)
        data = data.astype(np.float32)
        if np.max(np.abs(data)) > 0:
            data = data / np.max(np.abs(data)) * 0.8
        if sample_rate_in != sample_rate:
            data = scipy.signal.resample_poly(data, sample_rate, sample_rate_in)
        max_samples = int(sample_rate * slot / 1000)
        data = data[:max_samples]
        start_idx = int(sample_rate * start / 1000)
        end_idx = min(start_idx + len(data), len(final))
        if start_idx < len(final):
            final[start_idx:end_idx] += data[: end_idx - start_idx]
    max_amp = np.max(np.abs(final))
    if max_amp > 1:
        final = final / max_amp * 0.95
    buffer = io.BytesIO()
    scipy.io.wavfile.write(buffer, sample_rate, final)
    buffer.seek(0)
    return buffer.read()


def build_dubbed_video(video_path: str, wav_bytes: bytes, srt_text: Optional[str] = None) -> bytes:
    tmp = tempfile.mkdtemp()
    wav_path = os.path.join(tmp, "audio.wav")
    out_path = os.path.join(tmp, "out.mp4")
    with open(wav_path, "wb") as handle:
        handle.write(wav_bytes)
    vf = "scale=trunc(iw/2)*2:trunc(ih/2)*2"
    if srt_text:
        sub_path = os.path.join(tmp, "subs.srt")
        with open(sub_path, "w", encoding="utf-8") as handle:
            handle.write(srt_text)
        escaped = sub_path.replace("\\", "/").replace(":", "\\:")
        vf = f"subtitles='{escaped}'," + vf
    cmd = [FFMPEG_EXE, "-y", "-i", video_path, "-i", wav_path, "-map", "0:v:0", "-map", "1:a:0", "-vf", vf, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "23", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", "-shortest", out_path]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(result.stderr)
    with open(out_path, "rb") as handle:
        data = handle.read()
    shutil.rmtree(tmp, ignore_errors=True)
    return data


def download_youtube_video(url: str) -> str:
    import yt_dlp

    tmpdir = tempfile.mkdtemp()
    template = os.path.join(tmpdir, "yt.%(ext)s")
    with yt_dlp.YoutubeDL({"format": "mp4/best", "outtmpl": template, "quiet": True, "noplaylist": True, "merge_output_format": "mp4"}) as ydl:
        info = ydl.extract_info(url, download=True)
        filename = ydl.prepare_filename(info)
        if filename.endswith(".mp4"):
            return filename
        return os.path.splitext(filename)[0] + ".mp4"


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/api/preload/translation")
def preload_translation():
    load_translation_model()
    return {"status": "ready"}


@app.post("/api/preload/whisper")
def preload_whisper():
    load_whisper_model()
    return {"status": "ready"}


@app.post("/api/preload/tts")
def preload_tts():
    load_tts_model("en")
    load_tts_model("hi")
    load_tts_model("mr")
    return {"status": "ready"}


@app.post("/api/preload/ocr")
def preload_ocr():
    load_ocr_reader("en")
    load_ocr_reader("hi")
    return {"status": "ready"}


@app.post("/api/text/translate")
def text_translate(payload: dict):
    text = payload.get("text", "")
    source = payload.get("source_language", "English")
    target = payload.get("target_language", "Hindi")
    if not text.strip():
        return {"translation": ""}
    try:
        future = TRANSLATION_EXECUTOR.submit(translate_text, text, LANGUAGES[source], LANGUAGES[target])
        translation = future.result(timeout=20)
        return {"translation": translation}
    except TimeoutError:
        return {"translation": "", "error": "translation model is still loading; please try again in a moment", "status": "timed_out"}
    except Exception as exc:
        return {"translation": "", "error": str(exc), "status": "failed"}


@app.post("/api/image/extract")
async def image_extract(file: UploadFile = File(...), source_language: str = Form("English")):
    contents = await file.read()
    try:
        image = Image.open(io.BytesIO(contents)).convert("RGB")
        extracted = ocr_image(image, LANGUAGES[source_language])
        return {"extracted_text": extracted, "status": "ok"}
    except Exception as exc:
        return {"extracted_text": "", "status": "failed", "error": str(exc)}


@app.post("/api/image/translate")
def image_translate(payload: dict):
    text = payload.get("text", "")
    source = payload.get("source_language", "English")
    target = payload.get("target_language", "Hindi")
    try:
        translation = translate_text(text, LANGUAGES[source], LANGUAGES[target])
        return {"translation": translation, "status": "ok"}
    except Exception as exc:
        return {"translation": "", "status": "failed", "error": str(exc)}


@app.post("/api/pdf/extract")
async def pdf_extract(file: UploadFile = File(...), source_language: str = Form("English")):
    contents = await file.read()
    extracted = extract_pdf_text_and_images(contents, LANGUAGES[source_language])
    return {"extracted_text": extracted}


@app.post("/api/pdf/translate")
def pdf_translate(payload: dict):
    text = payload.get("text", "")
    source = payload.get("source_language", "English")
    target = payload.get("target_language", "Hindi")
    translation = translate_text(text, LANGUAGES[source], LANGUAGES[target])
    return {"translation": translation}


@app.post("/api/video/process")
async def video_process(file: Optional[UploadFile] = File(None), youtube_url: str = Form(""), source_language: str = Form("English"), target_language: str = Form("Hindi")):
    if youtube_url and not file:
        tmp_path = download_youtube_video(youtube_url)
        try:
            transcript, blocks, error = transcribe_video(tmp_path, LANGUAGES[source_language])
            translation = translate_text(transcript, LANGUAGES[source_language], LANGUAGES[target_language]) if transcript else ""
            subtitles = make_translated_srt(blocks, LANGUAGES[source_language], LANGUAGES[target_language]) if blocks else ""
            return {"transcript": transcript, "translation": translation, "subtitles": subtitles, "error": error}
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
    if not file:
        raise HTTPException(status_code=400, detail="Please provide a video file or YouTube URL")
    contents = await file.read()
    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as handle:
        handle.write(contents)
        path = handle.name
    try:
        transcript, blocks, error = transcribe_video(path, LANGUAGES[source_language])
        translation = translate_text(transcript, LANGUAGES[source_language], LANGUAGES[target_language]) if transcript else ""
        subtitles = make_translated_srt(blocks, LANGUAGES[source_language], LANGUAGES[target_language]) if blocks else ""
        return {"transcript": transcript, "translation": translation, "subtitles": subtitles, "error": error}
    finally:
        if os.path.exists(path):
            os.remove(path)


@app.post("/api/video/dub")
async def video_dub(file: Optional[UploadFile] = File(None), youtube_url: str = Form(""), source_language: str = Form("English"), target_language: str = Form("Hindi"), burn_subtitles: bool = Form(False)):
    if youtube_url and not file:
        temp_path = download_youtube_video(youtube_url)
        try:
            transcript, blocks, error = transcribe_video(temp_path, LANGUAGES[source_language])
            subtitles = make_translated_srt(blocks, LANGUAGES[source_language], LANGUAGES[target_language]) if burn_subtitles and blocks else None
            wav_bytes = create_segment_dubbed_audio(blocks, LANGUAGES[source_language], LANGUAGES[target_language]) if blocks else None
            if error:
                raise HTTPException(status_code=500, detail=error)
            if not wav_bytes:
                raise HTTPException(status_code=500, detail="Audio generation failed")
            video_bytes = build_dubbed_video(temp_path, wav_bytes, subtitles)
            return Response(content=video_bytes, media_type="video/mp4", headers={"Content-Disposition": "attachment; filename=dubbed_video.mp4"})
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)
    if not file:
        raise HTTPException(status_code=400, detail="Please provide a video file or YouTube URL")
    contents = await file.read()
    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as handle:
        handle.write(contents)
        temp_path = handle.name
    try:
        transcript, blocks, error = transcribe_video(temp_path, LANGUAGES[source_language])
        subtitles = make_translated_srt(blocks, LANGUAGES[source_language], LANGUAGES[target_language]) if burn_subtitles and blocks else None
        wav_bytes = create_segment_dubbed_audio(blocks, LANGUAGES[source_language], LANGUAGES[target_language]) if blocks else None
        if error:
            raise HTTPException(status_code=500, detail=error)
        if not wav_bytes:
            raise HTTPException(status_code=500, detail="Audio generation failed")
        video_bytes = build_dubbed_video(temp_path, wav_bytes, subtitles)
        return Response(content=video_bytes, media_type="video/mp4", headers={"Content-Disposition": "attachment; filename=dubbed_video.mp4"})
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


@app.post("/api/live/translate")
async def live_translate(file: UploadFile = File(...), source_language: str = Form("Hindi"), target_language: str = Form("English")):
    contents = await file.read()
    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as handle:
        handle.write(contents)
        temp_path = handle.name
    try:
        transcript = transcribe_audio_file(temp_path, LANGUAGES[source_language], LANGUAGES[target_language])
        if not transcript.strip():
            return {
                "transcript": "",
                "translation": "",
                "audio": "",
                "error": "No speech was detected in the audio clip. Please try a clearer recording.",
            }
        translation = transcript if target_language == "English" and source_language != "English" else translate_text(transcript, LANGUAGES[source_language], LANGUAGES[target_language])
        audio_bytes = create_audio(translation, LANGUAGES[target_language], max_chars=700) or b""
        audio_b64 = base64.b64encode(audio_bytes).decode("ascii") if audio_bytes else ""
        return {"transcript": transcript, "translation": translation, "audio": audio_b64}
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)

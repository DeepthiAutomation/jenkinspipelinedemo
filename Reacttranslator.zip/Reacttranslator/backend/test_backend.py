import io
import os
import traceback
from PIL import Image, ImageDraw, ImageFont
import requests

base = 'http://127.0.0.1:8004'

print('Testing text translation...')
try:
    r = requests.post(base + '/api/text/translate', json={'text':'Hello world','source_language':'English','target_language':'Hindi'}, timeout=300)
    print('status', r.status_code)
    print(r.text)
except Exception as exc:
    print('text error', repr(exc))
    traceback.print_exc()

print('Testing image OCR...')
img = Image.new('RGB', (400, 120), color='white')
draw = ImageDraw.Draw(img)
font = ImageFont.load_default()
draw.text((20, 40), 'Hello World', fill='black', font=font)
buf = io.BytesIO()
img.save(buf, format='PNG')
buf.seek(0)
try:
    r = requests.post(base + '/api/image/extract', files={'file': ('test.png', buf.getvalue(), 'image/png')}, data={'source_language': 'English'}, timeout=300)
    print('status', r.status_code)
    print(r.text)
except Exception as exc:
    print('image error', repr(exc))
    traceback.print_exc()

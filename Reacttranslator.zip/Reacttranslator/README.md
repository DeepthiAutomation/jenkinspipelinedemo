# Reacttranslator

This folder contains a separate React frontend and FastAPI backend for a translator-style app.

## Structure
- frontend/: Vite + React app
- backend/: FastAPI server

## Run the backend
```bash
cd backend
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

## Run the frontend
```bash
cd frontend
npm install
npm run dev
```

The frontend will proxy `/api` requests to the backend.
